# NumPy_Tutorial

This folder holds the code to the following tutorial on Medium
[Fundamentals of NumPy](https://towardsdatascience.com/fundamentals-of-numpy-a7e94d260845?source=friends_link&sk=246e705be82f1683391d637376ee6481)
