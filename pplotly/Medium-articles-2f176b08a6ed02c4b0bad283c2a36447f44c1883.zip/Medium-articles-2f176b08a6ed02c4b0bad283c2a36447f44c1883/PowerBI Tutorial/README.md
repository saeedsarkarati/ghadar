This folder holds the necessary files for the following tutorial on Medium
<br />
[How to visualize data using Power BI?](https://towardsdatascience.com/how-to-visualize-data-using-power-bi-9ec1413e976e?source=friends_link&sk=ed4a6ce64e9fefbafcd8221471e47844)
