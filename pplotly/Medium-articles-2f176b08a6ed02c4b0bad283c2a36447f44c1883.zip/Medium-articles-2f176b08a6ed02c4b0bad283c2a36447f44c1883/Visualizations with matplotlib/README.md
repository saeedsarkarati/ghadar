This folder holds the necessary files for the following tutorial on Medium
<br />
[Visualizations with matplotlib](https://towardsdatascience.com/visualizations-with-matplotlib-4809394ea223)
